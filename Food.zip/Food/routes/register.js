var express = require('express');
var router = express.Router();
var registerdao=require("./../dao/registerDao");

/* GET home page. */
//router.get('/', function(req, res, next) {
//    res.render('register', { title: 'Express' });
//});
router.get("/",function(req,res){
    res.render("reg",{regsinfo:null});
});
router.post("/",function(req,res){
    res.render("reg",{regsinfo:null});
});

router.post("/add",function(request,response){

    var con = request.body.name;
    var con2=request.body.pwd;
    var con3=request.body.phone;
    console.log("here ---1" + con+con2+con3);
    /*registerdao.checkUserName(con, function (err,res) {
        if(res.toString()=="") {
            console.log("here=====>");
            registerdao.regfood(con, con2,con3, function (err, res) {
                if (res != undefined) {
                    response.render("login",{regsinfo:null});
                } else {
                    response.send("sign-up failed!!");
                }
            });
        }else{
            response.send("用户名已存在，请重新注册");
        }
    });*/
    //registerdao.regfood(con,con2,con3, function (err, res) {
    //    response.render("login",{regsinfo:null});
    //});
});


module.exports = router;