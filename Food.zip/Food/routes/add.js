var express = require('express');
var router = express.Router();
var formidable=require("formidable");
var fs=require("fs");
var adddao=require("./../dao/addDao");
var AVATAR_UPLOAD_FOLDER = '/upload/';


/* GET home page. */
//router.get('/', function(req, res, next) {
//    res.render('add', { title: 'Express' });
//});
router.get('/', function(request, response, next) {
    adddao.findmessagesid(function(err,data){
        console.log("??????"+request.session.islogin);
        //console.log("----------",res);
        /*if(request.session.islogin==undefined){
                response.redirect("/users");
        }else{
            for(var i=0;i<data.length;i++){*/
                response.render('add', { title: data[0] ,tit:data[1],tt:data[2],tti:data[3],user:request.session.islogin,res:request.session.userid});
            //}
        //}
        //for(var i=0;i<data.length;i++){
        //
        //    response.render('add', { title: data[0] ,tit:data[1],tt:data[2],tti:data[3]});
        //}
    })

});



router.get("/addimg",function(request,response){

    console.log("add img ---init");

    response.render("add");

});
router.post("/addimg",function(request,response) {
    console.log('------------------------');
    console.log(request)
    console.log("add img ---post");
    var form = new formidable.IncomingForm();   //创建上传表单
    form.encoding = 'utf-8';        //设置编辑
    form.uploadDir = "../public" + AVATAR_UPLOAD_FOLDER;     //设置上传目录
    form.keepExtensions = true;     //保留后缀
    form.maxFieldsSize = 2 * 1024;   //文件大小

    form.parse(request, function (err, fields, files) {
        if (err) {
            response.locals.error = err;
            response.render("add", {title: null});
            return;
        }
        var extName = '';  //后缀名
        switch (files.bookimg.type) {
            case 'image/pjpeg':
                extName = 'jpg';
                break;
            case 'image/jpeg':
                extName = 'jpg';
                break;
            case 'image/png':
                extName = 'png';
                break;
            case 'image/x-png':
                extName = 'png';
                break;
        }

        if (extName.length == 0) {
            response.locals.error = '只支持png和jpg格式图片';
            response.render('error', {message: err});
            return;
        }

        var avatarName = Math.random() + '.' + extName;
        var newPath = form.uploadDir + avatarName;
        var con = avatarName;


        console.log("##########33", newPath + con);
        console.log("old" + files.bookimg.path);
        fs.renameSync(files.bookimg.path, newPath);  //重命名

        response.locals.success = '上 传成功..........';


        adddao.addfood(con, function (err, res) {
            var resulst = "";
        });
        console.log("here ---1" + con);

        response.redirect("/add");

        console.log("add img ---end");
    });


});




router.post("/addfood",function(request,response) {

        var ing_mail = request.body.ing_mail;
        var ing_acce = request.body.ing_acce;
        var ing_seas = request.body.ing_seas;
        var ing_step = request.body.ing_step;
        var menu_name = request.body.menu_name;
        var type_id = request.body.type_id;
        var beh_id = request.body.beh_id;
        var dif_id = request.body.dif_id;
        var user_id = request.body.user_id;
        var introduction = request.body.introduction;
        var t_id = request.body.t_id;
        //var bookimg = request.body.bookimg;
        console.log("********" + menu_name + type_id + beh_id + dif_id + introduction + t_id + user_id + ing_mail + ing_acce + ing_seas + ing_step);
        adddao.addfood(ing_mail, ing_acce, ing_seas, ing_step, menu_name, type_id, beh_id, dif_id, user_id, introduction, t_id, function (err, res) {
            response.render("veg", {title: null,user:request.session.islogin});

        });



});


module.exports = router;