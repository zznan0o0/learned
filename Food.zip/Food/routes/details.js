var express = require('express');
var router = express.Router();
var detailsdao=require("./../dao/vegDao");

/* GET home page. */
//router.get('/', function(request, response, next) {
//    dao.finding(function(err,res){
//        for(var i=0;i<res.length;i++){
//            response.render('reply', { title: res });
//
//        }
//    })
//});
router.get("/",function(req,res){
    console.log("??????"+req.session.islogin);

    if(req.session.islogin==undefined){
        res.render("details",{foodsinfo:null,user:null,title:null});
    }else{
        res.render("details",{foodsinfo:null,user:req.session.islogin});
    }
});

router.post("/",function(req,res){
    res.render("details",{foodsinfo:null});
});



router.get("/search",function(request,response){
    //var con=request.query.mid;
    //console.log("here ---1"+con);
    //dao.findfood(con,function(err,res){
    //    var resulst="";
    //    if(res!=undefined){
    //        for(var i=0;i<res.length;i++){
    //            resulst+="菜名:"+res[i].menu_name+"<br/>"+res[i].type_name;
    //        }
    //        //response.send(resulst);
    //        response.send(JSON.stringify(res));
    //
    //    }
    //
    //})
});

router.post("/search",function(request,response){
    var con=request.body.condition;
    console.log("here ---1"+con);
    detailsdao.findfood(con,function(err,res){

        response.json(res);
    });

});
router.post("/addcomment",function(request,response){
    var con=request.body.com;
    var id=request.body.mid;
    var uname=request.body.uname;
    console.log("**********" +con+id+uname);
    if(request.session.islogin==undefined){
        console.log("kkkkkk"+id);
        response.redirect("/users");
    }else{
        detailsdao.findcom(con,id,uname,function (err, res) {
            response.redirect("/veg/add/?id="+id);
        });
    }
    //detailsdao.findcom(con,id,uname,function (err, res) {
    //    response.redirect("/veg/add/?id="+id);
    //});
});



module.exports = router;
