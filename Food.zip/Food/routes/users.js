var express=require('express');
var router =express.Router();
var userdao=require("./../dao/userDao");

router.get("/",function(request,response){
  response.render("login",{usersinfo:null});
});

router.post("/",function(request,response){
  response.render("login",{usersinfo:null});
});

router.get("/search",function(req,res){
  if(req.session.islogin){
    console.log("hrrrr======"+req.session.islogin);
    res.locals.islogin=req.session.islogin;
  }
  res.render('login',{usersinfo:res});
});

router.post("/search",function(request,response){
  var username=request.body.uname;
  var pwd=request.body.pwd;
  userdao.finduser(username,function(err,res){
    if(res!=undefined) {
      if (pwd == res[0].pwd) {
        request.session.islogin = username;
        request.session.userid = res[0].user_id;
        console.log("+++++++++++++++++++++"+request.session.islogin);
        response.locals.islogin = request.session.islogin;
        console.log("here======>>"+res[0].user_name);
        response.json(res);
      }
      else{
        response.send("用户名或密码错误");
      }
    }
  });
});

module.exports=router;

