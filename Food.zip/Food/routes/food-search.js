var express=require("express");
//var app=express();
var router =express.Router();
var fs=require("fs");
//var bodyparser =require('body-parser');
//app.use(bodyparser.urlencoded({extended:false}));
var fooddao=require("./../dao/food-searchDao");

router.get("/",function(req,res){
    res.render("food-search",{foodsinfo:null});
});
router.post("/",function(req,res){
    res.render("food-search",{foodsinfo:null});
});


router.post("/search",function(request,response){
    var con=request.body.statetype;
    console.log("here ---1"+con);
    fooddao.findfood(con,function(err,res){

        response.json(res);
    });

});

module.exports=router;
