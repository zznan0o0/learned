var express = require('express');
var router = express.Router();
var vegdao=require("./../dao/vegDao");

/* GET users listing. */
router.get("/",function(req,res){
  //var id=request.query.mid;
  //vegdao.findcom2(id,function(err,res) {
    console.log("??????" + req.session.islogin);
    if (req.session.islogin == undefined) {
      res.render("veg", {title: res, user: null});
    } else {
      res.render("veg", {title: res, user: req.session.islogin});
    }
  //});

});
router.post("/",function(req,res){
  res.render("veg",{foodsinfo:null});
});

router.post("/search",function(request,response){
  var con=request.body.condition;
  console.log("here ---1"+con);
  vegdao.findfood(con,function(err,res){

    response.json(res);
  });

});
router.get("/ser",function(request,response){
  var con=request.query.id;
  console.log("here ---1"+con);
  vegdao.findfood(con,function(err,res){

    response.redirect("/veg");
    //if (request.session.islogin == undefined) {
    //  response.render("veg", {title: res, user: null});
    //} else {
    //  response.render("veg", {title: res, user: req.session.islogin});
    //}
  });


});

router.get("/add",function(request,response){
/*var id=request.query.id;
  console.log("///////////"+id);
  vegdao.findadd(id,function(err,data){
    console.log("??????"+request.session.islogin);
    //console.log("!!!!!!"+data[0].menu_name);
    //console.log("----------",res);
      if(request.session.islogin==undefined){
        response.render("details",{title:data[0],tit:data[1],user:null});
      }else{
        response.render("details",{title:data[0],tit:data[1],user:request.session.islogin});
      }
   //response.render('details',{title:res});
  });
*/
});

module.exports = router;
