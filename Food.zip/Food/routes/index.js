var express = require('express');
var router = express.Router();
var dao=require("./../dao/indexDao");
/* GET home page. */
//router.get('/', function(req, res, next) {
//  res.render('index', { title: 'Express' });
//});


router.get('/logout', function(req, res) {
  res.clearCookie('islogin');
  req.session.destroy();
  res.redirect('/');
});

router.get('/', function(request, response, next) {
  dao.findmessagesid(function(err,data){
    console.log(">>>>>>>>>>>>>>>>>"+request.session.islogin);
    for(var i=0;i<data.length;i++){
      if( request.session.islogin!=undefined){
        response.render('', { title: data[0],tit:data[1] ,user:request.session.islogin});
      }else{
        response.render('', { title: data[0],tit:data[1] ,user:null});
      }

    }
  })

});

module.exports = router;

