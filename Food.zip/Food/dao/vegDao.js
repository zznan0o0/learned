var mysql = require('mysql');
var conn=require("./../db-set");
module.exports= {
    finding: function (callback) {
        var client = mysql.createConnection(conn.consql);
        var con = 1;
        client.query(
            //'select * from ingredients limit ?',[con],
            'select * from all_menu where menu_id=?',[id],
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].menu_name);
                    }
                } catch (e) {
                    console.log("错误" + err.message);
                } finally {
                    client.end();
                }
                callback(err, res);
            }
        )
    },
    findadd: function (id,callback) {

        var client = mysql.createConnection(conn.consql);
        var data=[];
        console.log(">>>>>>>"+id);
        client.query(
            //'select * from ingredients limit ?',[con],
            'select * from all_menu where menu_id=?',[id],
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].menu_name);
                        console.log("========"+res[i].type_name);
                    }
                } catch (e) {
                    console.log("错误" + err.message);
                } finally {
                    client.end();
                }
                //callback(err, res);
                data.push(res);
            }
        ),
        client.query(
            'select * from comment where menu_id=?',[id],
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log("eeeeeee"+res[i].comment_content);
                    }
                } catch (e) {
                    console.log("错误" + err.message);
                } finally {
                    //client.end();
                }
                data.push(res);
                callback(err, data);
            }
        )
    },
    findfood: function (condition, callback) {
        var client = mysql.createConnection(conn.consql);
        var con = "%" + condition + "%";
        console.log(con);
        client.query(
            'select * from all_menu where menu_name like ? or type_name like ? or user_name like ? or beh_name like ? or dif_name like ? or t_time like ?', [con, con, con, con, con, con],

            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].menu_name);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    client.end();
                }
                callback(err, res);
            });

    },
    findtype: function (type_id, callback) {
        var client = mysql.createConnection(conn.consql);
        client.query(
            'select * from all_menu where type_name= ?', [type_id],

            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].type_name);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    client.end();
                }
                callback(err, res);
            });

    },
    findcom:function(com,id,uname,callback){
        var client = mysql.createConnection(conn.consql);
        client.query(
            'insert into comment (comment_content,time,menu_id,user_name) '+'values(?,?,?,?)',[com,new Date(),id,uname],
            function(err,res,fields){
                try{
                    console.log("$$$$$$$" +com,id);

                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
            });

    },
    findcom2:function(mid,callback){
        var client = mysql.createConnection(conn.consql);
        client.query(
            'select * from comment where menu_id=?',[mid],
            function(err,res,fields){
                try{
                    console.log("$$$$$$$" +mid);

                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
            });

    }

};