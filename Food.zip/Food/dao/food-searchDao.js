/**
 * Created by asus on 2015/11/24.
 */
var mysql=require('mysql');
var conn=require("./../db-set");
module.exports={
    findfoodByID:function(stateid,callback){
        var client = mysql.createConnection(conn.consql);
        client.query(
            'select * from state where state_id=?',[stateid],
            function(err,res,fields){
                try{
                    for(var i=0;i<res.length;i++){
                        console.log(res[i].state_type);
                    }
                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
            }
        );
    },
    findfood:function(statetype,callback){
        var client = mysql.createConnection(conn.consql);
        var con="%"+statetype+"%";
        client.query(
            'select * from state where state_type like ?',[con],
            function(err,res,fields){
                try{
                    for(var i=0;i<res.length;i++){
                        console.log(res[i].state_id);
                    }
                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
            });

    }
};


