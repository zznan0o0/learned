/**
 * Created by asus on 2015/11/24.
 */
var mysql = require('mysql');
var conn=require("./../db-set");
module.exports={

    regfood:function(name,pwd,phone,callback){
        var client = mysql.createConnection(conn.consql);
        client.query(
            'insert into user(user_name,pwd,user_phone)'+'values(?,?,?)',[name,pwd,phone],
            function(err,res,fields){
                try{
                    console.log(name,pwd,phone);
                    //for(var i=0;i<res.length;i++){
                    //    console.log(res[i].user_name);
                    //}
                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
            });

    },
    checkUserName: function (name,callback) {
        var client = mysql.createConnection(conn.consql);
        client.query(
            'select * from user where user_name=?' , [name],
            function (err,res,fields) {
                try{
                    console.log(res);
                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
                }
        )
    }
}

