/**
 * Created by asus on 2015/11/24.
 */
var mysql = require('mysql');
var conn=require("./../db-set");
module.exports={
    findmessagesid:function(callback){
        var client = mysql.createConnection(conn.consql);
        var con=3;
        var con1=8;
        var data=[];
        client.query(
            'select * from all_menu order by menu_id DESC LIMIT ?',[con],
            function(err,res,fields){
                try{
                    for(var i=0;i<res.length;i++){
                        console.log(res[i].introduction);
                    }
                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                //callback(err,res);
                data.push(res);
            }
        );
        client.query(
            'select * from type limit ?', [con1],
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log("===="+res[i].type_name);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    //client.end();
                }
                data.push(res);
                callback(err, data);
            }
        )

    }
    //findpicuterid:function(callback) {
    //    var client = mysql.createConnection(conn.consql);
    //    var con = 8;
    //
    //}

};