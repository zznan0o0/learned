/**
 * Created by asus on 2015/11/24.
 */
var mysql = require('mysql');
var conn=require("./../db-set");
module.exports= {
    findmessagesid: function (callback) {
        var client = mysql.createConnection(conn.consql);
        var con = 8;
        var con1 = 8;
        var con2 = 7;
        var con3 = 12;
        var data = [];
        client.query(
            'select * from type',
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].type_name);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    client.end();
                }
                data.push(res);
            }
        );
        client.query(
            'select * from behavior',
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].beh_name);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    //client.end();
                }
                data.push(res);

            }
        );
        client.query(
            'select * from difficult',
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].dif_name);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    //client.end();
                }
                data.push(res);
            }
        );
        client.query(
            'select * from f_time',
            function (err, res, fields) {
                try {
                    for (var i = 0; i < res.length; i++) {
                        console.log(res[i].t_time);
                    }
                } catch (e) {
                    console.log("错误");
                } finally {
                    //client.end();
                }
                data.push(res);
                callback(err, data);
            }
        );
    },


    addfood:function(ing_mail,ing_acce,ing_seas,ing_step,
                     menu_name,type_id,beh_id,dif_id,
                     user_id,introduction,t_id,callback){
        var client = mysql.createConnection(conn.consql);
        var ing_index;
        client.query(
            'insert into ingredients(ing_mail,ing_acce,ing_seas,ing_step) '+'values(?,?,?,?)',[ing_mail,ing_acce,ing_seas,ing_step],
            function(err,res,fields){
                try{
                    console.log("001>>>"+ing_mail,ing_acce,ing_seas,ing_step);

                }catch(e){
                    console.log("错误");
                }finally{
                    //client.end();
                }
                //callback(err,res);
            });

        client.query(
            'SELECT LAST_INSERT_ID() as "index"',
            function(err,res,fields){
                try{
                    console.log("002>>>>"+res[0].index);
                    ing_index=res[0].index;
                }catch(e){
                    console.log("错误");
                }finally{
                    console.log("come here");
                    client.query(
                        'insert into menu(menu_name,type_id,beh_id,dif_id,m_time,user_id,ing_id,introduction,t_id) values(?,?,?,?,?,?,?,?,?)',
                        [menu_name,type_id,beh_id,dif_id,new Date(),user_id,ing_index,introduction,t_id],
                        function(err,res,fields){
                            try{
                                console.log("003>>>>>"+menu_name,type_id,beh_id,dif_id,new Date(),user_id,ing_index,introduction,t_id);
                            }catch(e){
                                console.log("错误");
                            }finally{
                                client.end();
                            }
                            callback(err,res);
                        });
                }

            });


    }












    //addfood:function(ing_mail,ing_acce,ing_seas,ing_step,
    //                 menu_name,type_id,beh_id,dif_id,
    //                 user_id,introduction,t_id,bookimg,callback){
    //    var client = mysql.createConnection(conn.consql);
    //    var ing_index;
    //    client.query(
    //        'insert into ingredients(ing_mail,ing_acce,ing_seas,ing_step) '+'values(?,?,?,?)',[ing_mail,ing_acce,ing_seas,ing_step],
    //        function(err,res,fields){
    //            try{
    //                console.log("001>>>"+ing_mail,ing_acce,ing_seas,ing_step);
    //
    //            }catch(e){
    //                console.log("错误");
    //
    //            }finally{
    //                //client.end();
    //
    //            }
    //            //callback(err,res);
    //        });
    //
    //    client.query(
    //        'SELECT LAST_INSERT_ID() as "index"',
    //        function(err,res,fields){
    //            try{
    //                console.log("002>>>>"+res[0].index);
    //                ing_index=res[0].index;
    //            }catch(e){
    //                console.log("错误");
    //            }finally{
    //                console.log("come here");
    //                client.query(
    //                    'insert into menu(menu_name,type_id,beh_id,dif_id,m_time,id,ing_id,introduction,t_id,img) values(?,?,?,?,?,?,?,?,?,?)',
    //                    [menu_name,type_id,beh_id,dif_id,new Date(),user_id,ing_index,introduction,t_id,bookimg],
    //                    function(err,res,fields){
    //                        try{
    //                            console.log("003>>>>>"+menu_name,type_id,beh_id,dif_id,new Date(),user_id,ing_index,introduction,t_id,bookimg);
    //                        }catch(e){
    //                            console.log("错误");
    //                        }finally{
    //                            client.end();
    //                        }
    //                        callback(err,res);
    //                    });
    //            }
    //            //callback(err,res);
    //        });
    //
    //
    //}

};