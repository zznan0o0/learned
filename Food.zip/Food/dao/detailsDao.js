/**
 * Created by asus on 2015/11/24.
 */
var mysql = require('mysql');
var conn=require("./../db-set");

module.exports={
    finding:function(callback){
        var client = mysql.createConnection(conn.consql);
        var con=1;
        client.query(
            //'select * from ingredients limit ?',[con],
            //'select * from all_menu',
            'select * from all_menu where menu_id=?',[id],
            function(err,res,fields){
                try{
                    for(var i=0;i<res.length;i++){
                        console.log(res[i].menu_name);
                    }
                }catch(e){
                    console.log("错误"+ err.message);
                }finally{
                    client.end();
                }
                callback(err,res);
            }
        )
    },
    findfood:function(condition,callback){
        var client = mysql.createConnection(conn.consql);
        var con="%"+condition+"%";
        console.log(con);
        client.query(
            'select * from all_menu where menu_name like ? or type_name like ? or user_name like ? or beh_name like ? or dif_name like ?',[con,con,con,con,con,con],

            function(err,res,fields){
                try{
                    for(var i=0;i<res.length;i++){
                        console.log(res[i].menu_name);
                    }
                }catch(e){
                    console.log("错误");
                }finally{
                    client.end();
                }
                callback(err,res);
            });

    }





};