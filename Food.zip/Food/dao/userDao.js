/**
 * Created by asus on 2015/11/24.
 */
var mysql=require('mysql');
var conn=require('./../db-set');
module.exports={
    finduser:function(uname,callback){
        var client = mysql.createConnection(conn.consql);
        console.log("uname:"+uname);
        client.query(
            'select * from user where user_name= ?',[uname],
            function(err,res,fields){

                try{
                    console.log("*******"+res[0].pwd);
                }
                catch(e){
                    console.log("用户名错误");
                }finally{
                    client.end();
                    //console.log("111111"+client);
                }
                callback(err,res);
            });

    }

};
