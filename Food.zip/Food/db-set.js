/**
 * Created by asus on 2015/11/17.
 */
module.exports={
    consql:{
        host:'localhost',
        port:'3306',
        database:'food',
        user:'root',
        password:'root'
    }
};