/**
 * Created by Administrator on 2015/11/24.
 */
function check() {
    //trim(字串): 将字串首尾两端的空格移除

    //NAME验证
    var User = document.getElementById('txtname').value;
    if (User.length != 0) {
        var patt = new RegExp(/^[0-9A-Za-z]{6,}$/);//只能输入26个字母
        if (!patt.test(User)) {
            document.getElementById("result1").innerHTML = "请账号已经正确账号";
            return true;
        }
        else {
            document.getElementById("result1").innerHTML = " ";
        }
    }
    else {
        document.getElementById("result1").innerHTML = "请输入注册时用的账号呀";
        return false;
    }
    //pwd验证
    var User = document.getElementById('txtpwd').value;
    if (User.length != 0) {
        var patt = new RegExp(/^[0-9A-Za-z]{6,}$/);//只能输入26个字母
        if (!patt.test(User)) {
            document.getElementById("result2").innerHTML = "请输入正确的密码哦！";
            return true;
        }
        else {
            document.getElementById("result2").innerHTML = "   ";
        }
    }
    else {
        document.getElementById("result2").innerHTML = "请输入密码啊！！";
        return false;
    }

    var txtName = document.getElementById("txtname").value;
    var txtpwd = document.getElementById("txtpwd").value;
    if (txtName !== "" ||txtpwd !== "" ) {
    }
}