/**
 * Created by Administrator on 2015/11/25.
 */
function check() {
    //trim(字串): 将字串首尾两端的空格移除

    //NAME验证
    var User = document.getElementById('name').value;
    if (User.length != 0) {
        var patt = new RegExp(/^[0-9A-Za-z]{6,}$/);//只能输入26个字母
        if (!patt.test(User)) {
            document.getElementById("result1").innerHTML = "注册账号不能低于6位，请输入字母和数字";
            return true;
        }
        else {
            document.getElementById("result1").innerHTML = " ";
        }
    }
    else {
        document.getElementById("result1").innerHTML = "注册账号不能为空！";
        return false;
    }
    //pwd验证
    var User = document.getElementById('pwd').value;
    if (User.length != 0) {
        var patt = new RegExp(/^[0-9A-Za-z]{6,}$/);//只能输入26个字母
        if (!patt.test(User)) {
            document.getElementById("result2").innerHTML = "密码不能低于6位，密码类型是字母加上数字！";
            return true;
        }
        else {
            document.getElementById("result2").innerHTML = "   ";
        }
    }
    else {
        document.getElementById("result2").innerHTML = "注册密码也不能为空！！";
        return false;
    }

  /*  var User = document.getElementById('txteng').value;
    if (User.length != 0) {
        var patt = new RegExp(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/);//注册邮箱
        if (!patt.test(User)) {
            document.getElementById("result3").innerHTML = "请输入正确的邮箱！";
            return true;
        }
        else {
            document.getElementById("result3").innerHTML = "   ";
        }
    }
    else {
        document.getElementById("result3").innerHTML = "注册邮箱也不能为空！！";
        return false;
    }*/


    var txtName = document.getElementById("txtname").value;
    var txtpwd = document.getElementById("txtpwd").value;
   /* var txteng=document.getElementById("txteng").value;*/
    if (txtName !== "" ||txtpwd !== "" ) {

    }
}